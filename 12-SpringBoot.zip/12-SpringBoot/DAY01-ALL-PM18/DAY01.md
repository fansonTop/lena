### 1. SpringBoot框架

SpringBoot并不是一个全新的技术解决了新问题的框架！它更像是一个SpringMVC框架，但是，它极大程度的简化了相关的配置，它推荐使用“约定大于配置”的思想，框架本身已经完成了大量的基础配置，开发人员只需要知道“应该怎么做”就行，并不需要手动做相关的配置！

### 2. 创建SpringBoot项目

SpringBoot项目的创建方式有多种，可以直接从开发工具中创建，也可以基于SpringBoot的父级项目来创建所需的子级项目，或者，打开`https://start.spring.io`，在网站中配置所需要的项目，并下载项目，在Eclipse或其它开发工具中导入。

下载到的是项目的压缩包文件，其中的文件夹就是网站上生成好的项目，将文件夹解压出来后，应该先剪切到Workspace中(便于管理项目)，然后通过Eclipse的**Import** > **Existing Maven Project**导入项目。

当导入后，Eclipse会自动下载所需要的jar包，在这个过程中，务必保证当前计算机是可以连接到Maven服务器的！

如果使用的是SpringBoot 2.1.10或以上版本，应该使用Eclipse 4.10或以上版本，如果使用的Eclipse版本较低，在**pom.xml**中会提示错误信息，但是，不影响运行！

### 3. 启动SpringBoot项目

创建完成的项目中，已经存在`cn.tedu.sample`包，包名是根据创建项目时指定的**Group**和**Artifact**决定的，在这个包下有`SampleApplication`类，这个类的名称是根据**Artifact**决定的，这个类中有`main()`方法，执行该`main()`就可以启动整个项目！

在启动时，会启动内置的Tomcat，所以，在启动之前，务必保证此前没有正在运行的Tomcat，否则，就会因为端口冲突导致失败！

**注意：创建好项目后，默认就存在的包(`cn.tedu.sample`)是整个项目的根包，SpringBoot已经配置了组件扫描就扫这个包，所以，使用该项目时，创建的所有组件类都必须放在这个包或其子包中！**

### 4. 创建控制器类接收客户端的请求

创建`cn.tedu.sample.controller.HelloController`控制器类，在类之前添加`@Controller`注解，并在类中编写简单的处理请求的方法：

	@Controller
	public class HelloController {
		
		@RequestMapping("hello.do")
		@ResponseBody
		public String showHello() {
			return "欢迎使用SpringBoot框架！！！";
		}
	
	}

完成后，在浏览器中，通过`http://localhost:8080/hello.do`即可访问。

**注意：由于SpringBoot项目使用内置的Tomcat，这个Tomcat只管理当前这1个项目，部署项目时，不需要通过项目名称来区分多个项目，所以，使用的Context Path是空值(空字符串)，在访问时，URL中不需要添加项目名称！**

**注意：SpringBoot项目默认使用8080端口，可以在src/main/resource/application.properties中修改，这个文件是SpringBoot项目的配置文件，在其中添加配置`server.port=8888`即可将端口号改为`8888`。如果使用Windows操作系统，还可以将端口号修改为`80`，由于`80`端口是HTTP协议的默认端口，所以，在访问时，URL中不必显式的指定端口号，而Linux/MacOS中对于`80`端口的权限是敏感的，需要在操作系统中另行设置才可以使用！在修改端口号时，推荐使用4位数或5位数的端口号，不推荐随便使用低位端口号，避免发生冲突。**

### 5. 显示静态页面

**注意：在SpringBoot项目的src/main/resources/static文件夹是专门用于存放静态资源的，包括.html、.css、.js、各种图片等资源。**

在**static**文件夹下创建**index.html**静态网页，页面内容可以自行设计。

**注意：index.html是默认的页面，所以，在访问时，URL中也不必显式的输入页面名称！**

### 6. 连接数据库

如果使用MyBatis + MySQL编程，需要在项目中添加依赖：

	<dependency>
		<groupId>org.mybatis.spring.boot</groupId>
		<artifactId>mybatis-spring-boot-starter</artifactId>
		<version>2.1.1</version>
	</dependency>

	<dependency>
		<groupId>mysql</groupId>
		<artifactId>mysql-connector-java</artifactId>
		<scope>runtime</scope>
	</dependency>

也在在此前创建项目时直接在网页中勾选！

**注意：在SpringBoot项目中，添加常规的依赖时，是不需要指定版本号的，SpringBoot会自动挑选合适的版本(通常是较新的且稳定的版本)！也可以自行添加`<version>`节点配置版号！**

**注意：当添加数据库相关依赖后，SpringBoot项目在启动时，就会尝试读取数据库连接的相关信息，如果没有配置这些信息，会启动失败！**

由于目前项目在报错，所以，首先需要在**application.properties**文件中添加数据库连接相关的配置，最小化配置为：

	spring.datasource.url=jdbc:mysql://localhost:3306/tedu_ums?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
	spring.datasource.username=root
	spring.datasource.password=root

以上最小化配置中，不需要配置驱动类，因为SpringBoot框架会自动在jar包中查询驱动类的位置！如果使用的是较低版本的`mysql-connector-java`包，可能需要自行配置，属性名为`spring.datasource.driver-class-name`。

由于启动项目时，只是读取相关配置，并不会尝试连接数据库，所以，即使配置的值是错的，也不影响启动，或者，目前根本看不出来配置是否正确！

为了检查配置值是否正确，应该执行单元测试！在项目的**src/test/java**下就已经存在`cn.tedu.sample`项目的根包，并且，在根包下已经有`SampleApplicationTests`测试类了，在类中，也有1个空的测试方法，应该先直接执行这个空的测试方法，如果出错，一定是环境有问题，例如某些依赖的jar包文件是损坏的，就需要删除损坏的jar包文件，并重新更新Maven，如果测试通过，则可以继续测试数据库连接！

**注意：SpringBoot项目的测试类之前必须添加`@RunWith(SpringRunner.class)`和`@SpringBootTest`注解(在SpringBoot 2.2.x版本中已经简化)，用于加载Spring环境和各种配置！**

在`SampleApplicationTests`类中编写测试方法，则检查数据库连接：

	@Autowired
	DataSource dataSource;
	
	@Test
	public void getConnection() throws SQLException {
		Connection conn = dataSource.getConnection();
		System.err.println(conn);
	}

> 可以简单的理解为：以前在SpringMVC、MyBatis等案例中，通过`ac.getBean()`方式获取的对象，在SpringBoot中，都可以通过自动装配的方式，使得对象被注入值！

### 7. 使用MyBatis开发“用户注册”的持久层功能

先创建`cn.tedu.sample.entity.User`实体类：

	public class User {

		private Integer id;
		private String username;
		private String password;
		private Integer age;
		private String phone;
		private String email;

	}

再创建`cn.tedu.sample.mapper.UserMapper`接口，并在接口中定义抽象方法：

	Integer insert(User user);

	User findByUsername(String username);

还需要指定接口文件的位置，使得MyBatis框架能知道接口在哪里！可以在接口的声明之前添加`@Mapper`注解，但是，使用这种做法就必须在每个MyBatis接口之前都添加该注解，所以，也可以使用另一种做法，就是在启动类(`SampleApplication`)的声明之前添加`@MapperScan`注解：

	@MapperScan("cn.tedu.sample.mapper")
	@SpringBootApplication
	public class SampleApplication {
	
		public static void main(String[] args) {
			SpringApplication.run(SampleApplication.class, args);
		}
	
	}

如果没有配置接口的位置，后续运行时，将无法获取接口的对象！

关于配置SQL语句，可以直接在接口的抽象方法之前添加对应的注解，即：根据需要执行的SQL语句的种类，从`@Insert`、`@Delete`、`@Update`、`@Select`中选择一个，然后在注解属性中配置SQL语句：

	@Insert("insert into t_user ("
			+ "username,password,age,phone,email"
			+ ") values ("
			+ "#{username},#{password},"
			+ "#{age},#{phone},"
			+ "#{email}"
			+ ")")
	Integer insert(User user);

> 这种做法并不是SpringBoot的特点！在普通的MyBatis项目中也可以这样做，只不过相比前课的案例，需要添加更多的配置！

以上做法的可读性较差，添加更多的配置信息时，难度反而更大，所以，仍推荐使用XML文件来完成配置！所以，在**src/main/resources**下创建**mappers**文件夹，在文件夹中粘贴得到**UserMapper.xml**文件，并在文件内部进行配置：

	<mapper namespace="cn.tedu.sample.mapper.UserMapper">
	
		<insert id="insert">
			INSERT INTO t_user (
				username, password,
				age, phone,
				email
			) VALUES (
				#{username}, #{password},
				#{age}, #{phone},
				#{email}
			)
		</insert>

		<select id="findByUsername"
			resultType="cn.tedu.sample.entity.User">
			SELECT * FROM t_user WHERE username=#{username}
		</select>
	
	</mapper>

接下来，还需要配置XML文件的位置，需要在**application.properties**中进行配置：

	mybatis.mapper-locations=classpath:mappers/*.xml

最后，在**src/test/java**下创建`cn.tedu.sample.mapper.UserMapperTests`测试类，在类的声明之前添加必要的注解，并在类中编写并执行单元测试：

	@RunWith(SpringRunner.class)
	@SpringBootTest
	public class UserMapperTests {
	
		@Autowired
		UserMapper userMapper;
		
		@Test
		public void insert() {
			User user = new User();
			user.setUsername("springboot");
			user.setPassword("1234");
			Integer rows = userMapper.insert(user);
			System.err.println("rows=" + rows);
		}

		@Test
		public void findByUsername() {
			String username = "springboot";
			User result = userMapper.findByUsername(username);
			System.err.println(result);
		}
		
		@Test
		public void reg() {
			User user = new User();
			user.setUsername("root");
			user.setPassword("1234");
			
			User result = userMapper.findByUsername(user.getUsername());
			if (result == null) {
				userMapper.insert(user);
				System.err.println("注册成功！");
			} else {
				System.err.println("注册失败！用户名已经被占用！");
			}
		}
		
	}

### 8. 使用控制器接收客户端提交的注册请求

为了保证处理完请求后能够向客户端响应JSON数据，应该先创建`cn.tedu.sample.util.JsonResult`封装处理结果的类：

	public class JsonResult {
		private Integer state;
		private String message;
	}

创建`cn.tedu.sample.controller.UserController`新的控制器类，在类的声明之前添加`@Controller`和`@RequestMapping("user")`注解，在类中添加持久层对象：

	@RestController
	@RequestMapping("user")
	public class UserController {

		@Autowired
		private UserMapper userMapper;

	}

> 以上使用的`@RestController`也是用于控制器类的声明之前的，也表示当前类就是一个控制器类，同时，还表示当前控制器类中所有处理请求的方法都将响应正文，所以，`@RestController`就相当于`@Controller` + `@ResponseBody`！当控制器类之前添加了该注解后，该类中的各处理请求的方法之前都不必再添加`@ResponseBody`，这些方法都将响应正文，而不会转发或重定向！如果一定需要转发或重定向，就不应该使用`@RestController`，或者，使用`ModelAndView`作为处理请求的方法的返回值类型。另外，该注解并不是SpringBoot框架特有的，在普通的SpringMVC项目中也可以使用，只不过需要另外添加配置！

在类中添加处理请求的方法：

	@RequestMapping("reg")
	public JsonResult reg(User user) {
		JsonResult jsonResult = new JsonResult();
		User result = userMapper.findByUsername(user.getUsername());
		if (result == null) {
			userMapper.insert(user);
			// System.err.println("注册成功！");
			jsonResult.setState(1);
		} else {
			// System.err.println("注册失败！用户名已经被占用！");
			jsonResult.setState(2);
			jsonResult.setMessage("用户名已经被占用");
		}
		return jsonResult;
	}

完成后，打开浏览器，输入`http://localhost:8080/user/reg?username=Controller&password=1234`进行测试。

> 在配置请求路径时，还可以使用`@PostMapping`、`@GetMapping`等注解，并不一定始终是使用`@RequestMapping`，这些注解可以实现`@RequestMapping`的效果，并限制请求方式！也就是`@PostMapping("reg")`等同于`@RequestMapping(value="reg", method=RequestMethod.POST)`，这些注解如果是在SpringMVC项目中使用，也是需要另行配置的！

**注意：SpringBoot框架默认将SpringMVC中的DispatcherServlet处理的请求路径设置为`/*`，所以，所有请求都将被框架处理，在设计请求路径时，不必使用`.do`作为后缀。**