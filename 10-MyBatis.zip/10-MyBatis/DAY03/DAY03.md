### 1. 关于1对多关系的查询

需求：查询某个部门的信息，并显示该部门有哪些员工。

需要执行的SQL语句大致是：

	select 
		* 
	from 
		t_department 
	left join 
		t_user 
	on 
		t_department.id=t_user.department_id 
	where 
		t_department.id=?

为了封装查询结果，首先，需要创建对应的VO类：

	public class DepartmentVO {
		private Integer id;
		private String name;
		private List<User> users;
	}

在`DepartmentMapper`接口中添加抽象方法：

	DepartmentVO findVOById(Integer id);

如果某个部门有3个员工，则以上查询的SQL语句执行后，将得到3条结果，显然，在默认情况下，MyBatis并不知道如何将这3条结果封装到1个`DepartmentVO`对象中！在这种情况下，还是需要使用`<resultMap>`来指导MyBatis完成封装！

	<resultMap id="DepartmentVOMap"
		type="cn.tedu.mybatis.DepartmentVO">
		<id column="did" property="id"/>
		<result column="name" property="name"/>
		<!-- collection节点：配置1对多关系的(List集合类型)的属性 -->
		<!-- ofType属性：集合中的元素类型 -->
		<collection property="users"
			ofType="cn.tedu.mybatis.User">
			<id column="id" property="id"/>
			<result column="username" property="username"/>
			<result column="password" property="password"/>
			<result column="age" property="age"/>
			<result column="phone" property="phone"/>
			<result column="email" property="email"/>
			<result column="is_delete" property="isDelete"/>
			<result column="department_id" property="departmentId"/>
		</collection>
	</resultMap>

	<select id="findVOById"
		resultMap="DepartmentVOMap">
		SELECT 
			t_department.id AS did, name,
			t_user.* 
		FROM 
			t_department 
		LEFT JOIN
			t_user 
		ON 
			t_department.id=t_user.department_id 
		WHERE 
			t_department.id=#{id}
	</select>

在配置关联表查询的`<resultMap>`时，无论列名与属性名是否一致，都必须通过`<result>`节点进行配置！

### 2. MyBatis框架小结

1. 理解MyBatis框架的作用；

2. 认识相关的配置，包括：数据库连接的信息(db.properties)、读取连接的配置信息、配置数据源、配置接口文件的位置、配置SQL的XML文件的位置；

3. 基本了解MyBatis框架的执行流程；

4. 掌握抽象方法的设计原则：如果即将执行的操作是增删改类型的，返回`Integer`，如果即将执行的操作是查询，则根据期望的类型来设计即可，只要保证指定的类型可以封装查询结果即可；方法名称可以自定义，但是，不允许出现重载的方法；参数列表可以根据执行SQL语句时所需的参数来设计，当方法的参数超过1个时，需要为每个方法添加`@Param`注解；

5. 掌握基本的增删改查的SQL语句的配置；

6. 掌握动态SQL的`<foreach>`节点的配置；

7. 理解`#{}`和`${}`占位符的运行特征，在实际编程时，应该尽量使用`#{}`格式的占位符；

8. 理解在查询时定义别名的原则：如果需要列举查询的字段列表，且查询结果的列名与封装结果的属性名不一致时，可以自定义别名；如果多表查询，且查询结果中可能存在相同的列名，则应该为其中的某些列名定义别名，以保证查询结果的每一列的名称都不相同；

9. 理解`<resultMap>`的应用场景：查询时使用`*`表示字段列表，但是存在名称不对应的问题；多表查询时有1对多的关系，导致MyBatis不知道如何封装查询结果；

10. 掌握`<resultMap>`的配置：主要是配置列名与属性名的对应关系，在单表查询时，如果名称一致，则可以省略相关配置，如果多表联合查询，即使名称一致，也不可以省略；如果配置的是主键，需要使用`<id>`节点，如果配置的1对多关系的数据，需要使用`<collection>`节点，普通属性可以使用`<result>`节点。
	