### 1. 作业：写出各需求的SQL语句

1. 创建名为`tedu_ums`的数据库；

	CREATE DATABASE tedu_ums;
	USE tedu_ums;

2. 在以上数据库中，创建名为`t_user`的数据表，该表中应该至少包括id、用户名、密码、年龄、手机号码、电子邮箱这几个字段；

	CREATE TABLE t_user (
		id INT AUTO_INCREMENT COMMENT '用户id',
		username VARCHAR(20) NOT NULL UNIQUE COMMENT '用户名',
		password VARCHAR(20) NOT NULL COMMENT '密码',
		age INT COMMENT '年龄',
		phone VARCHAR(20) COMMENT '手机号码',
		email VARCHAR(30) COMMENT '电子邮箱',
		PRIMARY KEY (id)
	) DEFAULT CHARSET=utf8;

3. 插入不少于10条数据，每条数据的各字段值尽量随机；

	INSERT INTO t_user (username,password,phone,age) VALUES 
		('Henry', 'fdas', '13800138001', 26),
		('Zeo', 'vcvx', '13800138002', 21),
		('Alex', 'reer', '13800138003', 28),
		('Frank', 'jhgd', '13800138004', 22),
		('David', 'hgdf', '13800138005', 23),
		('Mike', 'cxvn', '13800138006', 20),
		('Lucy', 'qrec', '13800138007', 29),
		('Lily', 'rfdx', '13800138008', 24),
		('LiLei', 'nmhr', '13800138009', 27),
		('HanMM', 'uhjy', '13800138010', 32)
	;

4. 删除id=?的数据；

	DELETE FROM t_user WHERE id=?;

5. 一次性删除id=?、id=?、id=?的数据；

	DELETE FROM t_user WHERE id IN (?,?,?);

	DELETE FROM t_user WHERE id=? OR id=? OR id=?;

6. 将id=?的数据的电子邮箱改为?；

	UPDATE t_user SET email=? WHERE id=?;

7. 将所有用户的密码全部改为?；

	UPDATE t_user SET password=?;

8. 统计当前表中用户的数量；

	SELECT COUNT(*) FROM t_user;

9. 查询id=?的用户的数据；

	SELECT * FROM t_user WHERE ID=?;

10. 查询用户名=?的用户的数据；

	SELECT * FROM t_user WHERE username=?;

11. 查询所有用户的数据；

	SELECT * FROM t_user ORDER BY id;

12. 查询年龄最大的那1个用户的数据（假设所有用户的年龄值都不同）。

	SELECT * FROM t_user WHERE age=(SELECT MAX(age) FROM t_user);

	SELECT * FROM t_user ORDER BY age DESC LIMIT 0,1;

### 2. MyBatis框架的作用

MyBatis框架最直接的作用就是简化持久层开发！

> 持久层：处理数据持久化的组件；

> 持久化：将数据永久的存储下来；

使用MyBatis框架处理增删改查时，只需要定义功能的抽象方法，并配置这个抽象方法对应的SQL语句即可！

### 3. 创建项目

创建**Maven Project**，勾选**Create a simple Project**，**Group id**为`cn.tedu`，**Artifact id**为**MyBatis**，**Packaing**为`war`(不必要)。

创建完之后，还是应该：生成**web.xml**；添加Tomcat运行环境(不必要)；从前序项目中复制依赖；从前序项目中复制**spring.xml**；从前序项目中复制**web.xml**中的配置。

此次使用MyBatis框架，需要添加`mybatis`的依赖：

	<!-- MyBatis框架 -->
	<!-- 可选版本：3.5.0~3.5.3 -->
	<dependency>
		<groupId>org.mybatis</groupId>
		<artifactId>mybatis</artifactId>
		<version>3.5.3</version>
	</dependency>

MyBaits框架可以单独使用，但是，配置起来非常麻烦，通常会整合Spring框架一起使用，所以，还需要添加`mybatis-spring`的依赖：

	<!-- MyBatis整合Spring -->
	<!-- 可选版本：2.0.0~2.0.3 -->
	<dependency>
		<groupId>org.mybatis</groupId>
		<artifactId>mybatis-spring</artifactId>
		<version>2.0.3</version>
	</dependency>

整合了Spring之后，还需要添加`spring-context`依赖，当然，也可以直接使用此前就已经使用的`spring-webmvc`依赖，因为其中包含了`spring-context`依赖，同时，因为底层实现依然使用了JDBC相关技术，所以，需要另行添加`spring-jdbc`依赖，该依赖的版本必须与`spring-webmvc`的版本完全相同：

	<!-- Spring-JDBC -->
	<!-- 版本：与spring-webmvc完全一致 -->
	<dependency>
		<groupId>org.springframework</groupId>
		<artifactId>spring-jdbc</artifactId>
		<version>????????</version>
	</dependency>

另外，由于需要结合MySQL数据库编程，所以，还需要添加MySQL数据库连接的`mysql-connector-java`依赖：

	<!-- MySQL -->
	<!-- 可选版本：5.1.34~5.1.39，8.0.12~8.0.18 -->
	<dependency>
		<groupId>mysql</groupId>
		<artifactId>mysql-connector-java</artifactId>
		<version>8.0.18</version>
	</dependency>

然后，还应该添加数据库连接池`commons-dbcp`的依赖：

	<!-- 数据库连接池 -->
	<!-- 可选版本：1.2~1.4 -->
	<dependency>
		<groupId>commons-dbcp</groupId>
		<artifactId>commons-dbcp</artifactId>
		<version>1.4</version>
	</dependency>

最后，此次将通过单元测试检验开发的功能，所以，还需要添加`junit`的依赖。

另外，将**spring.xml**重命为**spring-mvc.xml**，将其复制一份，得到**spring-dao.xml**，删除**spring-dao.xml**中的配置。

### 4. 连接数据库

在**src/main/resources**下创建**db.properties**文件，并在其中配置连接数据库的信息：

	url=jdbc:mysql://localhost:3306/tedu_ums?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai
	driver=com.mysql.cj.jdbc.Driver
	username=root
	password=root
	initialSize=2
	maxActive=10

然后，应该在**spring-dao.xml**中配置`<util:properties>`节点读取以上配置信息：

	<!-- 读取连接数据库的配置文件 -->
	<util:properties id="dbConfig"
		location="classpath:db.properties" />

然后，配置`BasicDataSource`，并把以上读取到的配置信息注入到相关属性中：
	
	<!-- 数据源：BasicDataSource -->
	<bean id="dataSource" class="org.apache.commons.dbcp.BasicDataSource">
		<property name="url" value="#{dbConfig.url}"/>
		<property name="driverClassName" value="#{dbConfig.driver}"/>
		<property name="username" value="#{dbConfig.username}"/>
		<property name="password" value="#{dbConfig.password}"/>
		<property name="initialSize" value="#{dbConfig.initialSize}"/>
		<property name="maxActive" value="#{dbConfig.maxActive}"/>
	</bean>

完成后，可以在**src/test/java**下创建`cn.tedu.mybatis.Tests`测试类，以测试是否可以正确连接到数据库：

	public class Tests {
		
		ClassPathXmlApplicationContext ac;
		
		@Test
		public void getConnection() throws SQLException {
			BasicDataSource dataSource = (BasicDataSource) ac.getBean("dataSource");
			Connection conn = dataSource.getConnection();
			System.out.println(conn);
		}
		
		@Before
		public void doBefore() {
			ac = new ClassPathXmlApplicationContext(
				"spring-dao.xml");
		}
		
		@After
		public void doAfter() {
			ac.close();
		}
	
	}

### 5. 抽象方法

假设当前需要开发“向用户表中插入用户数据”的功能。

MyBatis要求相关的抽象方法都封装在接口中，所以，需要先创建`cn.tedu.mybatis.UserMapper`接口：

	public interface UserMapper {

	}

然后，在接口中声明要开发的功能对应的抽象方法，关于抽象方法的声明原则：

1. 如果即将执行的SQL语句是增、删、改类型的SQL语句，应该将返回值声明为`Integer`，表示“受影响的行数”，也可以声明为`void`，表示不关心受影响的行数是多少；如果即将执行的SQL语句是查询类型的SQL语句，返回值可以按需设计，只要能够封装查询结果即可；

2. 方法的名称可以自定义，但是，不允许出现重载的方法名；

3. 方法的参数列表可以根据执行SQL语句时需要哪些变量来决定，需要哪些变量，就添加哪些参数。

执行“插入用户数据”的SQL语句的格式大致是：

	insert into t_user (username,password,age,phone,email) values (?,?,?,?,?);

所以，抽象方法可以设计为：

	Integer xxx(String username, String password, Integer age, String phone, String email);

当然，参数的数量较多，或参数的数量可能发生变化时，所以，也可以将各数据进行封装：

	public class User {
		private String username;
		private String password;
		private Integer age;
		private String phone;
		private String email;
	}

则抽象方法还可以设计为：

	public interface UesrMapper {
		Integer addnew(User user);
	}

接下来，还需要配置接口文件的位置，所以在**spring-dao.xml**中配置`MapperScannerConfigurer`：

	<!-- 配置MapperScannerConfigurer -->
	<bean class="org.mybatis.spring.mapper.MapperScannerConfigurer">
		<!-- 配置接口文件所在的包 -->
		<property name="basePackage" value="cn.tedu.mybatis" />
	</bean>

### 6. SQL语句 

下载`http://doc.tedu.cn/config/mybatis-mapper.zip`，并解压得到**SomeMapper.xml**文件。

在**src/main/resources**下创建名为**mappers**的文件夹，将**SomeMapper.xml**复制到该文件夹中。

打开**SomeMapper.xml**，首先，添加根节点`<mapper>`，并在该节点中配置`namespace`属性，属性值是对应的接口文件的全名：

	<mapper namespace="cn.tedu.mybatis.UserMapper">

	</mapper>

然后，根据即将要执行的SQL语句的种类选择子级节点，子节点的`id`属性的值是对应的抽象方法的名称，再在子级配置需要执行的SQL语句：

	<!-- id属性：对应的抽象方法的名称 -->
	<insert id="addnew">
		INSERT INTO t_user (
			username, password,
			age, phone,
			email
		) VALUES (
			#{username}, #{password},
			#{age}, #{phone},
			#{email}
		)
	</insert>

注意：以上配置中，值列表部分的`#{}`的占位符里都是`addnew()`方法的参数`User`类型中的属性名！

然后，还需要配置`SqlSessionFactoryBean`，用于指定**XML配置文件的位置**和**使用哪个数据源连接数据库**，所以，在**spring-dao.xml**中配置：

	<!-- 配置SqlSessionFactoryBean -->
	<bean class="org.mybatis.spring.SqlSessionFactoryBean">
		<!-- 配置XML文件的位置 -->
		<property name="mapperLocations" value="classpath:mappers/*.xml" />
		<!-- 配置使用哪个数据源 -->
		<property name="dataSource" ref="dataSource" />
	</bean>

最后，先测试类中添加新的全局变量：

	UserMapper userMapper;

在`doBefore()`中补充获取该对象的值：

	@Before
	public void doBefore() {
		ac = new ClassPathXmlApplicationContext(
			"spring-dao.xml");
		userMapper = ac.getBean(
			"userMapper", UserMapper.class);
	}

然后，编写并执行单元测试：

	@Test
	public void addnew() {
		User user = new User();
		user.setUsername("Tommy");
		user.setPassword("o8ur");
		user.setAge(35);
		user.setPhone("13800138035");
		user.setEmail("tommy@163.com");
		Integer rows = userMapper.addnew(user);
		System.out.println("rows=" + rows);
	}

### 7. 删除id=?的数据

在`UserMapper`接口中添加抽象方法：

	Integer deleteById(Integer id);

在**SomeMapper.xml**中添加配置：

	<delete id="deleteById">
		DELETE FROM t_user WHERE id=#{id}
	</delete>

完成后，可以在`Tests`中编写单元测试：

	@Test
	public void deleteById() {
		Integer id = 5;
		Integer rows = userMapper.deleteById(id);
		System.out.println("rows=" + rows);
	}

### 8. 将所有用户的密码全部改为?

在`UserMapper`接口中添加抽象方法：

	Integer updatePassword(String password);

在**SomeMapper.xml**中添加配置：

	<update id="updatePassword">
		UPDATE t_user SET password=#{password}
	</update>

完成后，可以在`Tests`中编写单元测试：

	@Test
	public void updatePassword() {
		String password = "8888";
		Integer rows = userMapper.updatePassword(password);
		System.out.println("rows=" + rows);
	}

### 9. 统计当前表中用户的数量

在`UserMapper`接口中添加抽象方法：

	Integer count();

在**SomeMapper.xml**中添加配置：

	<select id="count" resultType="java.lang.Integer">
		SELECT COUNT(*) FROM t_user;
	</select>

**注意：在配置`<select>`节点时，必须指定`resultType`或`resultMap`属性中的某1个。**

完成后，可以在`Tests`中编写单元测试：

	@Test
	public void count() {
		Integer count = userMapper.count();
		System.out.println("count=" + count);
	}

### 10. 查询id=?的用户的数据

在`UserMapper`接口中添加抽象方法：

	User findById(Integer id);

在**SomeMapper.xml**中添加配置：

	<select id="findById" resultType="cn.tedu.mybatis.User">
		SELECT * FROM t_user WHERE id=#{id}
	</select>

完成后，可以在`Tests`中编写单元测试：

	@Test
	public void findById() {
		Integer id = 1000;
		User result = userMapper.findById(id);
		System.out.println(result);
	}

### 11. 查询所有用户的数据

在`UserMapper`接口中添加抽象方法：

	List<User> findAll();

在**SomeMapper.xml**中添加配置：

	<select id="findAll" resultType="cn.tedu.mybatis.User">
		SELECT * FROM t_user ORDER BY id
	</select>

**注意：如果查询的结果是某种对象，不管是查1个数据，还是查多个数据形成`List`集合，在配置SQL语句时，`resultType`都只用写对象归属的类型，即：查询结果是`List`集合时，只需要告诉MyBatis框架集合中放的是什么类型的数据即可！**

完成后，可以在`Tests`中编写单元测试：

	@Test
	public void findAll() {
		List<User> list = userMapper.findAll();
		System.out.println("size=" + list.size());
		for (User item : list) {
			System.out.println(item);
		}
	}















### -----------------------------

### 附1：关于提示Invalid bound statement (not found)的解决方案

出现以上错误提示的话，可能的原因有：

1. 在**spring-dao.xml**中没有配置`SqlSessionFactoryBean`的`mapperLocations`属性，或者配置值是错误的，例如：存储XML文件的文件夹叫**mappers**，但是，配置值却是`classpath:mapper/*.xml`；

2. 在**SomeMapper.xml**中，根节点的`namespace`值有误；

3. 在**SomeMapper.xml**中，子级的增删改查节点的`id`值不是抽象方法的名称；

4. 不要反复提问。