package cn.tedu.spring;

import org.springframework.stereotype.Component;

@Component
public class User {
	
	public User() {
		System.out.println("����User��Ķ���");
	}

}

