package cn.tedu.spring;

import org.springframework.web.servlet.DispatcherServlet;

public class Tests {

	DispatcherServlet ds;
	
}
