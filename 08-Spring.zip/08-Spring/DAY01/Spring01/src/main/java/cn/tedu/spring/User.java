package cn.tedu.spring;

public class User {

	public User() {
		super();
		System.out.println("通过User()创建对象！");
	}

}
