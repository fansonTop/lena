package cn.tedu.spring;

import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Tests {
	
	private ClassPathXmlApplicationContext ac;
	
	@Before
	public void doBefore() {
		// 加载Spring配置文件，获取Spring容器
		ac = new ClassPathXmlApplicationContext("spring.xml");
	}
	
	@Test
	public void testValue() {
		// 通过Spring容器获取对象
		User user = ac.getBean("user", User.class);
		// 测试
		System.out.println(user);
		System.out.println("name=" + user.getName());
		System.out.println("age=" + user.age);
		System.out.println("from=" + user.from);
	}
	
	@Test
	public void testRef() {
		// 通过Spring容器获取对象
		UserLoginServlet userLoginServlet
			= ac.getBean("userLoginServlet", UserLoginServlet.class);
		// 测试
		System.out.println(userLoginServlet);
		System.out.println(userLoginServlet.userDao);
	}
	
	@Test
	public void testConstructor() {
		Person person = ac.getBean("person", Person.class);
		Student student = ac.getBean("student", Student.class);
		System.out.println(person);
		System.out.println(person.from);
		System.out.println(student);
	}
	
	@Test
	public void testCollection() {
		SampleBean sampleBean = ac.getBean("sampleBean", SampleBean.class);
		System.out.println(sampleBean.names.getClass());
		System.out.println(sampleBean.names);
		System.out.println();
		System.out.println(sampleBean.cities.getClass());
		System.out.println(sampleBean.cities);
		System.out.println();
		System.out.println(Arrays.toString(sampleBean.skills));
		System.out.println();
		System.out.println(sampleBean.session.getClass());
		System.out.println(sampleBean.session);
		System.out.println();
		System.out.println(sampleBean.tools.getClass());
		System.out.println(sampleBean.tools);
		System.out.println();
		System.out.println(sampleBean.jdbcConfig.getClass());
		System.out.println(sampleBean.jdbcConfig);
		System.out.println("url=" + sampleBean.jdbcConfig.get("url"));
		System.out.println("driver=" + sampleBean.jdbcConfig.get("driver"));
		System.out.println("username=" + sampleBean.jdbcConfig.get("username"));
		System.out.println("password=" + sampleBean.jdbcConfig.get("password"));
	}
	
	@Test
	public void testSpringEL() {
		ValueBean valueBean = ac.getBean("valueBean", ValueBean.class);
		System.out.println("name=" + valueBean.name);
		System.out.println("username=" + valueBean.username);
		System.out.println("from=" + valueBean.from);
		System.out.println("password=" + valueBean.password);
	}
	
	@After
	public void doAfter() {
		// 释放资源
		ac.close();
	}

}









