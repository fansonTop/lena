package cn.tedu.spring;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;

public class ListTests {
	
	@Test
	public void testList() {
		List<String> strings = new ArrayList<String>();
		strings.add("str-2");
		strings.add("str-1");
		strings.add("str-4");
		strings.add("str-3");
		strings.add("str-5");
		strings.add("str-1");
		for (String string : strings) {
			System.out.println(string);
		}
	}
	
	@Test
	public void testSet() {
		Set<String> strings = new LinkedHashSet<String>();
		strings.add("str-2");
		strings.add("str-1");
		strings.add("str-1");
		strings.add("str-4");
		strings.add("str-3");
		strings.add("str-5");
		for (String string : strings) {
			System.out.println(string);
		}
	}

}





