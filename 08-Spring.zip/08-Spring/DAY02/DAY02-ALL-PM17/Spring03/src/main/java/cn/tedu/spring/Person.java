package cn.tedu.spring;

public class Person {
	
	public String from;

	public Person(String from) {
		super();
		this.from = from;
	}

}
