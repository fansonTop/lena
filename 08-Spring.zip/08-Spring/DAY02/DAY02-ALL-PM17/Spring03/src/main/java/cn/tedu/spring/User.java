package cn.tedu.spring;

public class User {

	private String name; // name -> Name -> setName
	public Integer age;
	public String from;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public void setFrom(String from) {
		this.from = from;
	}
	
}
