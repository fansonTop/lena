package cn.tedu.spring;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class SampleBean {
	
	// Lucy, Jack, Kate, Tom
	public List<String> names;
	
	// Beijing, Shanghai, Guangzhou, Shenzhen
	public Set<String> cities;
	
	// JavaOOP, JavaSE, MySQL, JDBC
	public String[] skills;
	
	// username=Billy, age=23, password=javaee
	public Map<String, Object> session;
	
	// Eclipse, MySQL, Office, Intellij IDEA
	public List<String> tools;
	
	// 值来自src/main/resources/jdbc.properties
	public Properties jdbcConfig;

	public void setNames(List<String> names) {
		this.names = names;
	}

	public void setCities(Set<String> cities) {
		this.cities = cities;
	}

	public void setSkills(String[] skills) {
		this.skills = skills;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setTools(List<String> tools) {
		this.tools = tools;
	}

	public void setJdbcConfig(Properties jdbcConfig) {
		this.jdbcConfig = jdbcConfig;
	}

}






