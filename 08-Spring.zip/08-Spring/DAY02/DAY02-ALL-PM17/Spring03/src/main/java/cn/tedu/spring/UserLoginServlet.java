package cn.tedu.spring;

public class UserLoginServlet {
	
	public UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

}
