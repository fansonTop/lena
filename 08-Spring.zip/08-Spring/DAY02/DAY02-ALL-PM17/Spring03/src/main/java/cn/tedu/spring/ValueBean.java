package cn.tedu.spring;

public class ValueBean {
	
	// 值：User类的对象中的name属性值
	public String name;
	
	// 值：SampleBean的names中的第3个值
	public String username;
	
	// 值：SampleBean的cities中的第2个值
	public String from;
	
	// 值：SampleBean的session的password
	public String password;

	public void setName(String name) {
		this.name = name;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
