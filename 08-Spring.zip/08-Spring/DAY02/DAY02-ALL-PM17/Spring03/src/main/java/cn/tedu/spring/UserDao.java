package cn.tedu.spring;

public class UserDao {

}
